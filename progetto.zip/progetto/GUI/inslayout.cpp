#include "inslayout.h"
#include "baselayout.h"

InsLayout::InsLayout(Controller *c):controllerPtr(c)
{
  this->setModal(true);
  this->setFont(StyleGUI::normalFont);
  this->setFixedSize(StyleGUI::insLayoutSize);
  info->setMinimumHeight(StyleGUI::insLayoutLabelHeight);
  info->setWordWrap(true);
  createLayout();
}

void InsLayout::createLayout()
{
  StyleGUI::setPalette();
  vbox->setSpacing(3);
  vbox->addStretch(1);
  vbox->addWidget(info);
  vbox->addSpacerItem(spacerItem);
  vbox->addWidget(x1);
  vbox->addWidget(baseMachine);
  vbox->addWidget(x2);
  vbox->addWidget(insertName);
  vbox->addWidget(x3);
  vbox->addWidget(selectOperativeSystem);
  vbox->addWidget(x4);
  vbox->addWidget(selectCaseColor);
  vbox->addWidget(x5);
  vbox->addWidget(selectCaseSize);
  vbox->addWidget(x6);
  vbox->addWidget(selectRam);
  vbox->addWidget(x7);
  vbox->addWidget(selectHdd);
  vbox->addWidget(x8);
  vbox->addWidget(selectNumMonitor);
  vbox->addWidget(x9);
  vbox->addWidget(selectScreenSize);
  vbox->addWidget(peripherals);
  vbox->addWidget(gamingPC);
  vbox->addWidget(touch);
  vbox->addSpacing(5);
  vbox->addWidget(okButton);
  vbox->addWidget(cancelButton);
  vbox->addStretch(1);
  hbox->addSpacing(5);
  hbox->addLayout(vbox);
  setLayout(hbox);
  setupDesktopComboBoxes();
}


void InsLayout::setupDesktopComboBoxes()
{
  selectNumMonitor->setEnabled(true);
  selectNumMonitor->setPalette(*StyleGUI::enabled);
  selectCaseSize->setEnabled(true);
  selectCaseSize->setPalette(*StyleGUI::enabled);
  gamingPC->setChecked(false);
  gamingPC->setEnabled(true);
  gamingPC->setPalette(*StyleGUI::enabled);
  peripherals->setText("Mouse + tastiera");
  peripherals->setChecked(false);
  selectScreenSize->setEnabled(false);
  selectScreenSize->setPalette(*StyleGUI::disabled);
  touch->setChecked(false);
  touch->setPalette(*StyleGUI::disabled);
  touch->setEnabled(false);
  if(selectOperativeSystem->currentIndex() == 2)
    selectOperativeSystem->setCurrentIndex(0);
  QStandardItemModel* model = qobject_cast<QStandardItemModel*>(selectOperativeSystem->model());
  if(model){
      QStandardItem *android = model->item(2);
      QStandardItem *noSystem = model->item(3);
      android->setEnabled(false);
      noSystem->setEnabled(true);
    }
}

void InsLayout::setupLaptopComboBoxes()
{
  selectScreenSize->setEnabled(true);
  selectScreenSize->setPalette(*StyleGUI::enabled);
  gamingPC->setChecked(false);
  gamingPC->setEnabled(true);
  gamingPC->setPalette(*StyleGUI::enabled);
  peripherals->setText("Mouse + tastiera");
  peripherals->setChecked(false);
  selectNumMonitor->setEnabled(false);
  selectNumMonitor->setPalette(*StyleGUI::disabled);
  selectCaseSize->setEnabled(false);
  selectCaseSize->setPalette(*StyleGUI::disabled);
  touch->setChecked(false);
  touch->setPalette(*StyleGUI::disabled);
  touch->setEnabled(false);
  if(selectOperativeSystem->currentIndex() == 2)
    selectOperativeSystem->setCurrentIndex(0);
  QStandardItemModel *model = qobject_cast<QStandardItemModel*>(selectOperativeSystem->model());
  if(model){
      QStandardItem *android = model->item(2);
      QStandardItem *noSystem = model->item(3);
      android->setEnabled(false);
      noSystem->setEnabled(true);
    }
}

void InsLayout::setupTabletComboBoxes()
{
  selectNumMonitor->setEnabled(false);
  selectNumMonitor->setPalette(*StyleGUI::disabled);
  selectScreenSize->setEnabled(false);
  selectScreenSize->setPalette(*StyleGUI::disabled);
  selectCaseSize->setEnabled(false);
  selectCaseSize->setPalette(*StyleGUI::disabled);
  gamingPC->setEnabled(false);
  gamingPC->setPalette(*StyleGUI::disabled);
  peripherals->setText("Pennino");
  touch->setPalette(*StyleGUI::enabled);
  touch->setEnabled(true);
  if(selectOperativeSystem->currentIndex() == 3)
    selectOperativeSystem->setCurrentIndex(0);
  QStandardItemModel* model = qobject_cast<QStandardItemModel*>(selectOperativeSystem->model());
  if(model){
      QStandardItem *android = model->item(2);
      QStandardItem *noSystem = model->item(3);
      android->setEnabled(true);
      noSystem->setEnabled(false);
    }
}

void InsLayout::setModifyingMode(ComputerListItem *item)
{
  int indx;
  switch (controllerPtr->storePtr->getTypeInt(item->getPtr())) {
    case 0:{
        baseMachine->setCurrentIndex(0);
        Desktop *x = static_cast<Desktop*>(item->getPtr());
        indx=selectNumMonitor->findText(QString::number(x->getNumMonitor()));
        selectNumMonitor->setCurrentIndex(indx);
      }break;
    case 1:{
        baseMachine->setCurrentIndex(1);
        Laptop *x = static_cast<Laptop*>(item->getPtr());
        indx=selectScreenSize->findText(QString::fromStdString(x->getScreenSize()));
        selectScreenSize->setCurrentIndex(indx);
      }break;
    case 2:{
        baseMachine->setCurrentIndex(2);
        Tablet *x = static_cast<Tablet*>(item->getPtr());
        gamingPC->setChecked(false);
        x->isTouch() ? touch->setChecked(true) : touch->setChecked(false);
      }break;
    }
  item->getPtr()->isForGaming() ? gamingPC->setChecked(true) : gamingPC->setChecked(false);
  item->getPtr()->hasPeripherals() ? peripherals->setChecked(true) : peripherals->setChecked(false);
  insertName->setText(QString::fromStdString(item->getPtr()->getName()));
  indx=selectOperativeSystem->findText(QString::fromStdString(item->getPtr()->getOperativeSystem()));
  selectOperativeSystem->setCurrentIndex(indx);
  indx=selectCaseColor->findText(QString::fromStdString(item->getPtr()->getColorCase()));
  selectCaseColor->setCurrentIndex(indx);
  indx=selectCaseSize->findText(QString::fromStdString(item->getPtr()->getSizeCase()));
  selectCaseSize->setCurrentIndex(indx);
  indx=selectRam->findText(QString::number(item->getPtr()->getRam()));
  selectRam->setCurrentIndex(indx);
  indx=selectHdd->findText(QString::number(item->getPtr()->getHdd()));
  selectHdd->setCurrentIndex(indx);
}


