#ifndef MYFILEDIALOG_H
#define MYFILEDIALOG_H
#include <QFileDialog>
#include <QDir>

class MyFileDialog: public QFileDialog
{
public:
  QString path;
  QString getPath() const;
  MyFileDialog(int);
  virtual ~MyFileDialog();
};

#endif // MYFILEDIALOG_H
