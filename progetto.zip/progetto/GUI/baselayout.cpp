#include "baselayout.h"
#include "inslayout.h"
#include <QDebug>

BaseLayout::BaseLayout(Controller *controller):controllerPtr(controller)
{
  createLayout();
  createMenus();
  restyleWidgets();
}

BaseLayout::~BaseLayout()
{

}

void BaseLayout::createLayout()
{
  // Colonna verticale di sinistra
  hbox->addSpacing(-15);
  hbox2->addWidget(titleLabel, 0, Qt::AlignLeft);
  hbox2->addWidget(sortButton, 0, Qt::AlignRight);
  vbox2->addLayout(hbox2);
  vbox2->addWidget(listWidget);

  // Colonna verticale di destra
  vbox->setSpacing(3);
  vbox->addStretch(1);
  vbox->addWidget(imgLabel);
  vbox->addWidget(infoLabel);
  vbox->addWidget(addButton, 0, Qt::AlignCenter);
  vbox->addWidget(modifyButton, 0, Qt::AlignCenter);
  vbox->addWidget(removeButton, 0, Qt::AlignCenter);
  vbox->addWidget(removeallButton, 0, Qt::AlignCenter);
  vbox->addStretch(1);

  // Layout Finale
  hbox->setContentsMargins(10, 35, 10, 10);
  hbox->addSpacing(15);
  hbox->addLayout(vbox2);
  hbox->addLayout(vbox);
  setLayout(hbox);
}

void BaseLayout::createMenus()
{
  myMenuBar->setMaximumHeight(StyleGUI::maxHeightBar);
  fileMenu = myMenuBar->addMenu(tr("&File"));
  fileMenu->addAction(loadAction);
  fileMenu->addAction(saveAction);
  fileMenu->addAction(exitAction);
  viewMenu = myMenuBar->addMenu(tr("&Ricerca"));
  viewMenu->addAction(searchAction);
  viewMenu->addAction(resetAction);
  toolsMenu = myMenuBar->addMenu(tr("&Strumenti"));
  toolsMenu->addAction(totalPriceAction);
}

void BaseLayout::restyleWidgets()
{
  StyleGUI::setPalette();
  // Restyling di QListWidget
  listWidget->setMinimumWidth(StyleGUI::listWidgetWidth);
  listWidget->setIconSize(StyleGUI::sizeListWidgetItemIcon);
  listWidget->setFont(StyleGUI::listFont);
  titleLabel->setFont(StyleGUI::bigFont);

  // Restyling infoLabel
  infoLabel->setFixedSize(StyleGUI::infoLabelSize);
  infoLabel->setFont(StyleGUI::normalFont);
  infoLabel->setText(getEmptyInfo());

  // Restyling imgLabel
  imgLabel->setFixedSize(StyleGUI::imgLabelSize);
  imgLabel->setStyleSheet("QLabel{background:white;}");
  setupPixmap(StyleGUI::noitem);

  // Restyling dei QPushButton
  sortButton->setArrowType(Qt::UpArrow);
  sortButton->setMinimumWidth(StyleGUI::minWidthSortButton);

  foreach (QPushButton *button, listQPushButtons) {
      button->setMinimumWidth(StyleGUI::minWidthButton);
      button->setMinimumHeight(StyleGUI::minHeightButton);
      button->setFont(StyleGUI::normalFont);
    }
  checkButtons();
}

void BaseLayout::checkButtons()
{
  if (!listWidget->selectedItems().count()) {
      modifyButton->setPalette(*StyleGUI::disabled);
      modifyButton->setEnabled(false);
      removeButton->setPalette(*StyleGUI::disabled);
      removeButton->setEnabled(false);
      removeallButton->setPalette(*StyleGUI::disabled);
      removeallButton->setEnabled(false);
    }

  if (listWidget->selectedItems().count()) {
      modifyButton->setPalette(*StyleGUI::enabled);
      modifyButton->setEnabled(true);
      removeButton->setPalette(*StyleGUI::enabled);
      removeButton->setEnabled(true);
      removeallButton->setPalette(*StyleGUI::enabled);
      removeallButton->setEnabled(true);
    }

  if (!listWidget->count()) {
      sortButton->setPalette(*StyleGUI::disabled);
      sortButton->setEnabled(false);
      removeallButton->setPalette(*StyleGUI::disabled);
      removeallButton->setEnabled(false);
      totalPriceAction->setDisabled(true);
      searchAction->setDisabled(true);
      saveAction->setDisabled(true);
      resetAction->setDisabled(true);
    }

  if (listWidget->count()) {
      sortButton->setPalette(*StyleGUI::enabled);
      sortButton->setEnabled(true);
      removeallButton->setPalette(*StyleGUI::enabled);
      removeallButton->setEnabled(true);
      totalPriceAction->setDisabled(false);
      searchAction->setDisabled(false);
      saveAction->setDisabled(false);
    }
}

QString BaseLayout::getEmptyInfo() const
{
  return
      QString::fromStdString("\n")+"\n"+"\n"+"\n"+"\n"+"\n"+"\n"+"\n"+"\n"+"\n";
}

double BaseLayout::getCurrentTotalPrice() const
{
  double price=0;
  for (int i=0; i<listWidget->count(); ++i) {
      ComputerListItem *item = static_cast<ComputerListItem*>(listWidget->item(i));
      price += item->data(Qt::UserRole).toDouble();
    }
  return price;
}

void BaseLayout::clearListWidget()
{
  while (listWidget->count()) {
      listWidget->takeItem(0);
    }
}

void BaseLayout::setupPixmap(QString x) const
{
  QPixmap img(x);
  imgLabel->setPixmap(img.scaled(StyleGUI::imgLabelSize, Qt::KeepAspectRatioByExpanding));
}

void BaseLayout::styleSelectedItems(Computer *item)
{
  infoLabel->setText(controllerPtr->storePtr->getInfo(item));
  imgLabel->setStyleSheet("QLabel{background-color:" + QString::fromStdString(item->getColorCase()) + ";}");
  changeImage(item);
  checkButtons();
}

void BaseLayout::changeImage(Computer*x) const
{
  switch (controllerPtr->storePtr->getTypeInt(x)) {
  case 0:
      setupPixmap(StyleGUI::urlDesktop);
      break;
  case 1:
      setupPixmap(StyleGUI::urlLaptop);
      break;
  case 2:
      setupPixmap(StyleGUI::urlTablet);
      break;
   }
}

void BaseLayout::addItemQListWidget(ComputerListItem *item, QWidget *toAdd)
{
  item->setSizeHint(StyleGUI::sizeListWidgetItem);
  listWidget->addItem(item);
  listWidget->setItemWidget(item, toAdd);
}

void BaseLayout::setIconComputerListItem(ComputerListItem *item, QString str) const
{
  item->setIcon(QIcon(str));
}

void BaseLayout::resizeEvent(QResizeEvent *event)
{
  QSize newSize = event->size();
  myMenuBar->setMinimumWidth(newSize.width());
}
