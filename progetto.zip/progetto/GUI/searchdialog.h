#ifndef SEARCHDIALOG_H
#define SEARCHDIALOG_H

#include <QDialog>
#include <QLineEdit>
#include <QVBoxLayout>
#include <QLabel>
#include <QCheckBox>
#include <QPushButton>
#include <QColor>

#include "controller.h"
#include "elementsGUI/stylegui.h"
#include "elementsGUI/ramcombobox.h"
#include "elementsGUI/hddcombobox.h"
#include "elementsGUI/monitorcombobox.h"
#include "elementsGUI/operativesystemcombobox.h"
#include "elementsGUI/screensizecombobox.h"
#include "elementsGUI/casecolorcombobox.h"
#include "elementsGUI/casesizecombobox.h"
#include "elementsGUI/typecombobox.h"

class SearchDialog: public QDialog
{
  Q_OBJECT
public:
  SearchDialog(Controller *controller=nullptr);
  virtual ~SearchDialog();

  Controller *controllerPtr;

public:
  void createLayout();

public slots:
  void disableButtons();

public:
  QVBoxLayout *vbox = new QVBoxLayout();
  QVBoxLayout *vbox2 = new QVBoxLayout();
  QHBoxLayout *hbox = new QHBoxLayout();
  QHBoxLayout *hbox2 = new QHBoxLayout();

  QLabel *x1 = new QLabel("Tipo:");
  QLabel *x2 = new QLabel("Nome:");
  QLabel *x3 = new QLabel("Sistema operativo:");
  QLabel *x4 = new QLabel("Colore Case:");

  QCheckBox *searchByType = new QCheckBox("Voglio cercare per tipo");
  QCheckBox *searchByName = new QCheckBox("Voglio cercare per nome");
  QCheckBox *searchByOperativeSystem = new QCheckBox("Voglio cercare per sistema operativo");
  QCheckBox *searchByColor = new QCheckBox("Voglio cercare per colore");
  QCheckBox *searchByPrice = new QCheckBox("Voglio cercare per prezzo");

  QLineEdit *insertName = new QLineEdit();
  OperativeSystemComboBox *selectOperativeSystem = new OperativeSystemComboBox();
  QCheckBox *peripherals = new QCheckBox("Mouse + tastiera");
  TypeComboBox *baseMachine = new TypeComboBox();
  CaseColorComboBox *selectCaseColor = new CaseColorComboBox();

  QLabel *x10 = new QLabel("Prezzo:");
  QLabel *x11 = new QLabel("Maggiore di: ");
  QLabel *x12 = new QLabel("Minore di: ");

  QLineEdit *minPrice = new QLineEdit();
  QLineEdit *maxPrice = new QLineEdit();

  QPushButton *searchButton = new QPushButton("Search");
  QPushButton *cancelButton = new QPushButton("Cancel");
};

#endif // SEARCHDIALOG_H
