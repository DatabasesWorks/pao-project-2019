#include "controller.h"
#include "baselayout.h"
#include "inslayout.h"
#include "tooldialog.h"
#include "searchdialog.h"

Controller::Controller(Store *s): storePtr(s)
{
  setWindowTitle("PCOUI - PC Ordering User Interface");
  setWindowIcon(QIcon(StyleGUI::urlIcon));
  baseLayoutPtr = new BaseLayout(this);
  baseLayoutPtr->controllerPtr = this;
  setCentralWidget(baseLayoutPtr);
  createConnectsBaseLayout();

  openFileSlot();
  populateQListWidget(storePtr->container);

  flagStart = false;      // Setto false dopo la prima apertura del programma
  baseLayoutPtr->checkButtons();
}

Controller::~Controller()
{

}

void Controller::clearList()
{
  storePtr->container.clear();
  baseLayoutPtr->clearListWidget();
  baseLayoutPtr->restyleWidgets();
}

void Controller::populateQListWidget(Qontainer<Computer*> &vec)
{
  for (auto it=vec.begin(); it!=vec.end(); ++it) {
      ComputerListItem *item = new ComputerListItem(*it);
      setupComputerListItem(item);
    }
}

void Controller::setupComputerListItem(ComputerListItem *item)
{
  Computer *obj = item->getPtr();
  item->setInfo();
  setUpIcons(item);
  baseLayoutPtr->addItemQListWidget(item, widgetItemList->createLayoutPriceWidget(QString::number(obj->getTotalPrice())));
}

void Controller::setUpIcons(ComputerListItem *item)
{
  switch (storePtr->getTypeInt(item->getPtr())) {
  case 0:
      baseLayoutPtr->setIconComputerListItem(item, StyleGUI::urlDesktopIcon);
      break;
  case 1:
      baseLayoutPtr->setIconComputerListItem(item, StyleGUI::urlLaptopIcon);
      break;
  case 2:
      baseLayoutPtr->setIconComputerListItem(item, StyleGUI::urlTabletIcon);
      break;
    }
}

// =====================
// ==    Connects     ==
// =====================
// BaseLayout
void Controller::createConnectsBaseLayout()
{
  // Connects: Buttons
  connect(baseLayoutPtr->addButton, SIGNAL(clicked()),this, SLOT(openInsertLayoutSlot()));
  connect(baseLayoutPtr->modifyButton, SIGNAL(clicked()),this, SLOT(openModifyLayoutSlot()));
  connect(baseLayoutPtr->removeallButton, SIGNAL(clicked()),this, SLOT(removeAllItemsSlot()));
  connect(baseLayoutPtr->removeButton, SIGNAL(clicked()),this, SLOT(removeSelectedSlot()));
  connect(baseLayoutPtr->sortButton, SIGNAL(clicked()),this, SLOT(orderPriceSlot()));

  // Connects: Menu Actions
  connect(baseLayoutPtr->loadAction, SIGNAL(triggered()),this, SLOT(openFileSlot()));
  connect(baseLayoutPtr->saveAction, SIGNAL(triggered()),this, SLOT(saveFileSlot()));
  connect(baseLayoutPtr->exitAction, SIGNAL(triggered()),this, SLOT(closeBaseLayout()));
  connect(baseLayoutPtr->totalPriceAction, SIGNAL(triggered()),this, SLOT(openToolDialogSlot()));
  connect(baseLayoutPtr->searchAction, SIGNAL(triggered()),this, SLOT(openSearchSlot()));
  connect(baseLayoutPtr->resetAction, SIGNAL(triggered()),this, SLOT(resetSearchSlot()));

  // Connects: ListWidget
  connect(baseLayoutPtr->listWidget, SIGNAL(itemClicked(QListWidgetItem*)),this, SLOT(showObjectInfoSlot(QListWidgetItem*)));
}

// InsLayout
void Controller::createConnectsInsLayout()
{
  // flagCreate == true -> si sta creando un oggetto
  // flagCreate == false -> si sta modificando un oggetto
  // Connects: Buttons
  if (flagCreated)
    connect(insLayoutPtr->okButton, SIGNAL(clicked()),this, SLOT(createObjectSlot()));
  if (!flagCreated)
    connect(insLayoutPtr->okButton, SIGNAL(clicked()),this, SLOT(modifyObjectSlot()));

  connect(insLayoutPtr->cancelButton,SIGNAL(clicked()),this, SLOT(rejectInsLayout()));

  connect(insLayoutPtr->baseMachine, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged),this,[=](){
      switch (insLayoutPtr->baseMachine->currentIndex()) {
      case 0:
          insLayoutPtr->setupDesktopComboBoxes();
          break;
      case 1:
          insLayoutPtr->setupLaptopComboBoxes();
          break;
      case 2:
          insLayoutPtr->setupTabletComboBoxes();
          break;
        }
    });
}

// SearchDialog
void Controller::createConnectsSearchDialog()
{
  connect(searchDialogPtr->searchButton, SIGNAL(clicked()),this, SLOT(filterBySlot()));
  connect(searchDialogPtr->cancelButton, SIGNAL(clicked()),this, SLOT(rejectSearchSlot()));
}

// ToolDialog
void Controller::createConnectsToolDialog()
{
  connect(toolDialogPtr->okButton, SIGNAL(clicked()),this, SLOT(rejectToolDialog()));
}

// WarningDialog
void Controller::createConnectsWarningDialog()
{
  connect(warningDialogPtr->yesButton, SIGNAL(clicked()),this, SLOT(acceptWarningDialog()));
  connect(warningDialogPtr->noButton, SIGNAL(clicked()),this, SLOT(rejectWarningDialog()));
}



// =====================
// ==      Slots      ==
// =====================
// BaseLayout
void Controller::showObjectInfoSlot(QListWidgetItem *item) const
{
  ComputerListItem *customItem = static_cast<ComputerListItem*>(item);
  Computer *tmp = customItem->getPtr();
  baseLayoutPtr->styleSelectedItems(tmp);
}

void Controller::removeSelectedSlot()
{
  ComputerListItem *customItem = static_cast<ComputerListItem*>(baseLayoutPtr->listWidget->selectedItems().at(0));
  Computer *obj = customItem->getPtr();
  qDeleteAll(baseLayoutPtr->listWidget->selectedItems());
  storePtr->container.erase(obj);
  baseLayoutPtr->restyleWidgets();
}

void Controller::removeAllItemsSlot()
{
  clearList();
  baseLayoutPtr->checkButtons();
}

void Controller::orderPriceSlot()
{
  switch (sortFlag) {
  case 0:{
        baseLayoutPtr->listWidget->sortItems(Qt::DescendingOrder);
        baseLayoutPtr->sortButton->setArrowType(Qt::DownArrow);
        sortFlag = 1;
      }break;
  case 1:{
        baseLayoutPtr->listWidget->sortItems(Qt::AscendingOrder);
        baseLayoutPtr->sortButton->setArrowType(Qt::UpArrow);
        sortFlag = 0;
      }break;
    }
}

void Controller::closeBaseLayout()
{
  this->close();
}

// MyFileDialog
void Controller::openFileSlot()
{
  MyFileDialog *openFile = new MyFileDialog(0);
  if (!openFile->path.isNull()){
      QString tmp = openFile->getPath();
      storePtr->setPath(tmp);
      if (!flagStart){
          warningDialogPtr = new WarningDialog();
          createConnectsWarningDialog();
        }
      storePtr->readJson();
    }
  baseLayoutPtr->restyleWidgets();
}

void Controller::saveFileSlot()
{
  MyFileDialog *saveFile = new MyFileDialog(1);
  if (!saveFile->path.isNull()){
      storePtr->path = saveFile->path;
      storePtr->saveJson();
    }
}

// InsLayout
void Controller::openInsertLayoutSlot()
{
  insLayoutPtr = new InsLayout(this);
  createConnectsInsLayout();
  insLayoutPtr->setWindowIcon(QIcon(StyleGUI::urlIcon));
  insLayoutPtr->show();

  if (flagCreated) {
      insLayoutPtr->setWindowTitle("Crea Computer");
      insLayoutPtr->baseMachine->setEnabled(true);
    }

  if (!flagCreated) {
      ComputerListItem *item = static_cast<ComputerListItem*>(baseLayoutPtr->listWidget->selectedItems().at(0));
      insLayoutPtr->setWindowTitle("Modifica Computer");
      insLayoutPtr->baseMachine->setDisabled(true);
      insLayoutPtr->setModifyingMode(item);
    }
}

void Controller::openModifyLayoutSlot()
{
  flagCreated = false;
  openInsertLayoutSlot();
}

void Controller::createObjectSlot()
{
  Computer *object = nullptr;
  string nome=insLayoutPtr->insertName->text().toStdString();
  string sistemaO=insLayoutPtr->selectOperativeSystem->currentText().toStdString();
  string caseColor=insLayoutPtr->selectCaseColor->currentText().toStdString();
  string caseSize=insLayoutPtr->selectCaseSize->currentText().toStdString();
  int hdd=insLayoutPtr->selectHdd->currentText().toInt();
  int ram=insLayoutPtr->selectRam->currentText().toInt();
  int numMonitor=insLayoutPtr->selectNumMonitor->currentText().toInt();
  bool accessori=insLayoutPtr->peripherals->isChecked();
  bool gaming=insLayoutPtr->gamingPC->isChecked();
  string screenSize=insLayoutPtr->selectScreenSize->currentText().toStdString();
  bool touch=insLayoutPtr->touch->isChecked();
  switch (insLayoutPtr->baseMachine->currentIndex()) {
  case 0:
      object = new Desktop(sistemaO,nome,caseSize,caseColor,gaming,accessori,hdd,ram,numMonitor);
      break;
  case 1:
      caseSize = "Non disponibile per Laptop.";
      object = new Laptop(sistemaO,nome,caseSize,caseColor,gaming,accessori,hdd,ram,screenSize);
      break;
  case 2:
      caseSize = "Non disponibile per Tablet.";
      object = new Tablet(sistemaO,nome,caseSize,caseColor,gaming,accessori,hdd,ram,touch);
      break;
    }

  if (object)
    {
      storePtr->addItem(object);
      ComputerListItem *item = new ComputerListItem(object);
      setupComputerListItem(item);
    }
  baseLayoutPtr->restyleWidgets();
  flagCreated = !flagCreated;
  insLayoutPtr->done(insLayoutPtr->Accepted);
}

void Controller::modifyObjectSlot()
{
  ComputerListItem *item = static_cast<ComputerListItem*>(baseLayoutPtr->listWidget->selectedItems().at(0));
  Computer *x = item->getPtr();
  x->setName(insLayoutPtr->insertName->text().toStdString());
  x->setOperativeSystem(insLayoutPtr->selectOperativeSystem->currentText().toStdString());
  x->setColorCase(insLayoutPtr->selectCaseColor->currentText().toStdString());
  x->setSizeCase(insLayoutPtr->selectCaseSize->currentText().toStdString());
  x->setHdd(insLayoutPtr->selectHdd->currentText().toInt());
  x->setRam(insLayoutPtr->selectRam->currentText().toInt());
  switch(insLayoutPtr->baseMachine->currentIndex()){
  case 0:{
        Desktop *d = static_cast<Desktop*>(x);
        d->setNumMonitor(insLayoutPtr->selectNumMonitor->currentText().toInt());
        d->setPeripherals(insLayoutPtr->peripherals->isChecked());
        d->setGaming(insLayoutPtr->gamingPC->isChecked());
      }break;
  case 1:{
        Laptop *d = static_cast<Laptop*>(x);
        d->setSizeCase("Non disponibile per Laptop.");
        d->setPeripherals(insLayoutPtr->peripherals->isChecked());
        d->setGaming(insLayoutPtr->gamingPC->isChecked());
        d->setScreenSize(insLayoutPtr->selectScreenSize->currentText().toStdString());
      }break;
  case 2:{
        Tablet *d = static_cast<Tablet*>(x);
        d->setSizeCase("Non disponibile per Tablet.");
        d->setPeripherals(insLayoutPtr->peripherals->isChecked());
        d->setGaming(false);
        d->setTouch(insLayoutPtr->touch->isChecked());
      }break;
    }
  item->setInfo();
  baseLayoutPtr->restyleWidgets();
  flagCreated = !flagCreated;
  insLayoutPtr->done(insLayoutPtr->Accepted);
}

void Controller::rejectInsLayout() const
{
  insLayoutPtr->done(insLayoutPtr->Rejected);
}

// SearchDialog
void Controller::openSearchSlot()
{
  searchDialogPtr = new SearchDialog(this);
  searchDialogPtr->setWindowIcon(QIcon(StyleGUI::urlIcon));
  createConnectsSearchDialog();
  searchDialogPtr->show();
}

void Controller::filterBySlot()
{
  baseLayoutPtr->clearListWidget();

  QString type;
  if (searchDialogPtr->searchByType->isChecked())
    type=searchDialogPtr->baseMachine->currentText();
  else
    type = nullptr;

  QString name;
  if (searchDialogPtr->searchByName->isChecked())
    name=searchDialogPtr->insertName->text();
  else
    name = nullptr;

  QString color;
  if (searchDialogPtr->searchByColor->isChecked())
    color=searchDialogPtr->selectCaseColor->currentText();
  else
    color = nullptr;

  QString operativeSystem;
  if (searchDialogPtr->searchByOperativeSystem->isChecked())
    operativeSystem=searchDialogPtr->selectOperativeSystem->currentText();
  else
    operativeSystem = nullptr;

  double x;
  double y;
  if (searchDialogPtr->searchByPrice->isChecked()){
      x=searchDialogPtr->minPrice->text().toDouble();
      y=searchDialogPtr->maxPrice->text().toDouble();
    } else {
      x=-2;
      y=-2;
    }
  storePtr->search(type,name,color,operativeSystem,x,y);
  populateQListWidget(storePtr->resContainer);
  baseLayoutPtr->checkButtons();
  baseLayoutPtr->resetAction->setEnabled(true);
  searchDialogPtr->done(searchDialogPtr->Accepted);
}

void Controller::resetSearchSlot()
{
  baseLayoutPtr->clearListWidget();
  storePtr->resContainer.clear();
  populateQListWidget(storePtr->container);
  baseLayoutPtr->resetAction->setEnabled(false);
}

void Controller::rejectSearchSlot() const
{
  searchDialogPtr->done(searchDialogPtr->Rejected);
}

// ToolDialog
void Controller::openToolDialogSlot()
{
  toolDialogPtr = new ToolDialog(this);
  toolDialogPtr->priceLabel->setText(QString::number(baseLayoutPtr->getCurrentTotalPrice())+ " €");
  toolDialogPtr->show();
  createConnectsToolDialog();
}

void Controller::rejectToolDialog() const
{
  toolDialogPtr->done(toolDialogPtr->Rejected);
}

// WarningDialog
void Controller::acceptWarningDialog()
{
  clearList();
  storePtr->readJson();
  populateQListWidget(storePtr->container);
  baseLayoutPtr->checkButtons();
  warningDialogPtr->done(warningDialogPtr->Accepted);
}

void Controller::rejectWarningDialog() const
{
  warningDialogPtr->done(warningDialogPtr->Rejected);
}
