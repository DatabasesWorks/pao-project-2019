#include "searchdialog.h"

SearchDialog::SearchDialog(Controller *c):controllerPtr(c)
{
  this->setModal(true);
  this->setWindowTitle("Cerca Computer");
  this->setFixedSize(StyleGUI::searchDialogSize);
  this->setFont(StyleGUI::normalFont);
  createLayout();
  disableButtons();

  minPrice->setValidator(new QIntValidator(0, 9999, this));
  maxPrice->setValidator(new QIntValidator(0, 9999, this));

  connect(searchByType, SIGNAL(clicked(bool)),this, SLOT(disableButtons()));
  connect(searchByName, SIGNAL(clicked(bool)),this, SLOT(disableButtons()));
  connect(searchByOperativeSystem, SIGNAL(clicked(bool)),this, SLOT(disableButtons()));
  connect(searchByColor, SIGNAL(clicked(bool)),this, SLOT(disableButtons()));
  connect(searchByPrice, SIGNAL(clicked(bool)),this, SLOT(disableButtons()));
}

SearchDialog::~SearchDialog()
{

}

// Functions
void SearchDialog::createLayout()
{
  vbox->setSpacing(3);
  vbox->addStretch(1);
  vbox->addWidget(searchByType);
  vbox->addWidget(baseMachine);
  vbox->addWidget(searchByName);
  vbox->addWidget(insertName);
  vbox->addWidget(searchByOperativeSystem);
  vbox->addWidget(selectOperativeSystem);
  vbox->addWidget(searchByColor);
  vbox->addWidget(selectCaseColor);

  vbox->addWidget(searchByPrice);
  hbox2->addWidget(x11);
  hbox2->addWidget(minPrice,0,Qt::AlignLeft);
  hbox2->addWidget(x12);
  hbox2->addWidget(maxPrice,0,Qt::AlignRight);
  vbox->addLayout(hbox2);

  vbox->addSpacing(5);
  vbox->addWidget(searchButton);
  vbox->addWidget(cancelButton);
  vbox->addStretch(1);
  hbox->addSpacing(5);
  hbox->addLayout(vbox);
  setLayout(hbox);
}

// Slots
void SearchDialog::disableButtons()
{
  if (searchByType->isChecked()) {
      baseMachine->setEnabled(true);
      baseMachine->setPalette(*StyleGUI::enabled);
    }
  if (!searchByType->isChecked()) {
      baseMachine->setEnabled(false);
      baseMachine->setPalette(*StyleGUI::disabled);
    }
  if (searchByName->isChecked()) {
      insertName->setEnabled(true);
      insertName->setPalette(*StyleGUI::enabled);
    }
  if (!searchByName->isChecked()) {
      insertName->setEnabled(false);
      insertName->setPalette(*StyleGUI::disabled);
    }
  if (searchByOperativeSystem->isChecked()) {
      selectOperativeSystem->setEnabled(true);
      selectOperativeSystem->setPalette(*StyleGUI::enabled);
    }
  if (!searchByOperativeSystem->isChecked()) {
      selectOperativeSystem->setEnabled(false);
      selectOperativeSystem->setPalette(*StyleGUI::disabled);
    }
  if (searchByColor->isChecked()) {
      selectCaseColor->setEnabled(true);
      selectCaseColor->setPalette(*StyleGUI::enabled);
    }
  if (!searchByColor->isChecked())  {
      selectCaseColor->setEnabled(false);
      selectCaseColor->setPalette(*StyleGUI::disabled);
    }
  if (searchByPrice->isChecked()) {
      minPrice->setEnabled(true);
      minPrice->setPalette(*StyleGUI::enabled);
      maxPrice->setEnabled(true);
      maxPrice->setPalette(*StyleGUI::enabled);
    }
  if(!searchByPrice->isChecked()) {
      minPrice->setEnabled(false);
      minPrice->setPalette(*StyleGUI::disabled);
      maxPrice->setEnabled(false);
      maxPrice->setPalette(*StyleGUI::disabled);
    }
}


