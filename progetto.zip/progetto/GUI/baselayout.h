#ifndef BASELAYOUT_H
#define BASELAYOUT_H

#include <QWidget>
#include <QVBoxLayout>
#include <QPushButton>
#include <QListWidget>
#include <QLabel>
#include <QPixmap>
#include <QMenuBar>
#include <QResizeEvent>
#include <QToolButton>


#include "controller.h"
#include "elementsGUI/stylegui.h"
#include "elementsGUI/widgetcomputerlistitem.h"

class InsLayout;
class BaseLayout : public QWidget
{
  Q_OBJECT
public:
  BaseLayout(Controller *controller=nullptr);
  virtual ~BaseLayout();

  Controller *controllerPtr;    // Puntatore a Controller

public:
  void createLayout();   // Crea il layout usando QVBoxLayout e QHBoxLayout
  void createMenus();    // Crea il QMenuBar, aggiunge i QMenu e infine i QAction
  void restyleWidgets(); // Cambia lo stile, la dimensione etc dei widgets
  void checkButtons();   // Funzione che cambia lo stile dei QPushButtons, QActions a seconda di alcune condizione

  QString getEmptyInfo() const;        // Ritorna una stringa costituita da "\n"
  double getCurrentTotalPrice() const; // Ritorna la somma dei prezzi totali dei computer nell'ordine corrente (QListWidget)
  void clearListWidget();              // 'Pulisce' QListWidget dai ComputerListItem

  void setupPixmap(QString) const;     // Inizializza un PixMap dall'url dell'immagine
  void styleSelectedItems(Computer *); // Aggiorna il testo di infoLabel e i il colore background di imgLabel a seconda del Computer
  void changeImage(Computer *) const;  // Cambia l'immagine a seconda del Computer

  void addItemQListWidget(ComputerListItem *, QWidget *);          // Aggiunge un ComputerListItem a QListWidget e un QWidget a ComputerListItem
  void setIconComputerListItem(ComputerListItem *, QString) const; // Inserisce l'icona adeguata, a seconda del tipo di Computer, ad ogni ComputerListItem
  void resizeEvent(QResizeEvent *);                                // Funzione usata per cambiare la lunghezza di QMenuBar *myMenuBar durante il resizing della finestra

public:
  QVBoxLayout *vbox = new QVBoxLayout();
  QVBoxLayout *vbox2 = new QVBoxLayout();
  QHBoxLayout *hbox = new QHBoxLayout();
  QHBoxLayout *hbox2 = new QHBoxLayout();
  QListWidget *listWidget = new QListWidget();
  QLabel *imgLabel = new QLabel();
  QLabel *infoLabel = new QLabel();
  QLabel *titleLabel = new QLabel("Lista Ordinazioni:");

  QPushButton *addButton = new QPushButton("Crea un nuovo Computer");
  QPushButton *modifyButton = new QPushButton("Modifica il Computer selezionato");
  QPushButton *removeButton = new QPushButton("Rimuovi il Computer selezionato");
  QPushButton *removeallButton = new QPushButton("Rimuovi tutti i computer dall lista");
  QList<QPushButton*> listQPushButtons = {addButton, modifyButton, removeButton, removeallButton};

  QToolButton *sortButton = new QToolButton();

  QMenuBar *myMenuBar = new QMenuBar(this);
  QMenu *fileMenu, *viewMenu, *toolsMenu;
  QAction *loadAction = new QAction("Carica da Json", this);
  QAction *saveAction = new QAction("Salva lista", this);
  QAction *exitAction = new QAction("Esci", this);
  QAction *searchAction = new QAction("Cerca nella lista", this);
  QAction *resetAction = new QAction("Reset ricerca", this);
  QAction *totalPriceAction = new QAction("Prezzo totale", this);
};

#endif // BASELAYOUT_H
