#include "warningdialog.h"

WarningDialog::WarningDialog()
{
  this->setWindowFlags(Qt::Dialog | Qt::CustomizeWindowHint | Qt::WindowTitleHint);
  this->setFont(StyleGUI::normalFont);
  this->setWindowTitle("Attenzione!");
  okButton->setFixedWidth(StyleGUI::warningDialogButtonWidth);
  yesButton->setFixedWidth(StyleGUI::warningDialogButtonWidth);
  noButton->setFixedWidth(StyleGUI::warningDialogButtonWidth);
  this->setFixedSize(StyleGUI::warningDialogSize);
  this->setModal(true);
  this->show();
  modifyWarning->setWordWrap(true);
  modifyWarning->setAlignment(Qt::AlignJustify);
  modifyWarning->setText(QString::fromStdString("Caricando un file Json perderai tutte le modifiche effettuate. Sei sicuro di voler continuare?"));
  verticalLayout->addWidget(modifyWarning);
  horizontalLayout->addWidget(yesButton);
  horizontalLayout->addWidget(noButton);
  verticalLayout->addLayout(horizontalLayout);
  this->setLayout(verticalLayout);

}
