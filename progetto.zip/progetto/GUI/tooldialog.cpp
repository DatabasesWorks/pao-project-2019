#include "tooldialog.h"

ToolDialog::ToolDialog(Controller *c): controllerPtr(c)
{
  this->setWindowFlags(Qt::Dialog | Qt::CustomizeWindowHint | Qt::WindowTitleHint);
  this->setModal(true);
  this->setWindowTitle("Prezzo totale ordine corrente");
  createLayout();
  restyleWidgets();
}

void ToolDialog::createLayout()
{
  vbox->setSpacing(3);
  vbox->addStretch(1);
  vbox->addWidget(x);
  vbox->addWidget(priceLabel);
  vbox->addWidget(okButton);
  vbox->addStretch(1);
  hbox->addSpacing(3);
  hbox->addLayout(vbox);
  setLayout(hbox);
}

void ToolDialog::restyleWidgets(){
  x->setFont(StyleGUI::normalFont);
  priceLabel->setFont(StyleGUI::biggerFont);
  priceLabel->setAlignment(Qt::AlignCenter);
  this->setFixedSize(StyleGUI::toolDialogSize);
}
