#include "myfiledialog.h"

MyFileDialog::MyFileDialog(int flag)
{
  QString str = "./";
  switch (flag) {
  case 0:{
        this->setAcceptMode(QFileDialog::AcceptOpen);
        path =
            QFileDialog::getOpenFileName(this, tr("Apri File Json"), str+QDir::currentPath(), tr("Json Files (*.json)"));
      }break;
  case 1:{
        this->setAcceptMode(QFileDialog::AcceptSave);
        path =
            QFileDialog::getSaveFileName(this, tr("Salva File Json"), str+QDir::currentPath()+str, tr("Json Files (*.json)"));
      }break;
  }
}

MyFileDialog::~MyFileDialog()
{

}

QString  MyFileDialog::getPath() const
{
  return path;
}
