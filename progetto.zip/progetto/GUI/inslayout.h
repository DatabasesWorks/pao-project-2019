#ifndef INSLAYOUT_H
#define INSLAYOUT_H

#include <QDialog>
#include <QLineEdit>
#include <QVBoxLayout>
#include <QLabel>
#include <QCheckBox>
#include <QPushButton>
#include <QIcon>
#include <QSpacerItem>
#include <QStandardItem>

#include "controller.h"
#include "elementsGUI/stylegui.h"
#include "elementsGUI/ramcombobox.h"
#include "elementsGUI/hddcombobox.h"
#include "elementsGUI/monitorcombobox.h"
#include "elementsGUI/operativesystemcombobox.h"
#include "elementsGUI/screensizecombobox.h"
#include "elementsGUI/casecolorcombobox.h"
#include "elementsGUI/casesizecombobox.h"
#include "elementsGUI/typecombobox.h"

class InsLayout: public QDialog
{
  Q_OBJECT
public:
  InsLayout(Controller *controller=nullptr);
  virtual ~InsLayout(){}

  Controller *controllerPtr; // Puntatore a Controller

public:
  void createLayout();           // Crea il layout della finestra usando QVBoxLayout e QHBoxLayout
  void setupDesktopComboBoxes(); // Cambia quali QComboBox possono essere modificati se la baseMachine selezionata e' un desktop
  void setupLaptopComboBoxes();  // Cambia quali QComboBox possono essere modificati se la baseMachine selezionata e' un laptop
  void setupTabletComboBoxes();  // Cambia quali QComboBox possono essere modificati se la baseMachine selezionata e' un tablet
  void setModifyingMode(ComputerListItem *); // Cambia i valori dei QComboBox con i valori del Computer selezionato dopo aver premuto BaseLayout -> modifyButton

public:
  QVBoxLayout *vbox = new QVBoxLayout();
  QHBoxLayout *hbox = new QHBoxLayout();

  QLabel *info = new QLabel("Costruisci il computer dei tuoi sogni con PC-OUI!");
  QLabel *x1 = new QLabel("Tipo:");
  QLabel *x2 = new QLabel("Nome:");
  QLabel *x3 = new QLabel("Sistema operativo:");
  QLabel *x4 = new QLabel("Colore Case:");
  QLabel *x5 = new QLabel("Dimensione Case:");
  QLabel *x6 = new QLabel("Ram:");
  QLabel *x7 = new QLabel("Hdd:");
  QLabel *x8 = new QLabel("Numero monitor:");
  QLabel *x9 = new QLabel("Dimensione monitor laptop:");
  QCheckBox *peripherals = new QCheckBox("Mouse + tastiera");
  QCheckBox *gamingPC = new QCheckBox("Gaming");
  QCheckBox *touch = new QCheckBox("Touch");
  QLineEdit *insertName = new QLineEdit();

  TypeComboBox *baseMachine = new TypeComboBox();
  OperativeSystemComboBox *selectOperativeSystem = new OperativeSystemComboBox();
  CaseColorComboBox *selectCaseColor = new CaseColorComboBox();
  CaseSizeComboBox *selectCaseSize = new CaseSizeComboBox();
  RamComboBox *selectRam = new RamComboBox();
  HddComboBox *selectHdd = new HddComboBox();
  MonitorComboBox *selectNumMonitor = new MonitorComboBox();
  ScreenSizeComboBox *selectScreenSize = new ScreenSizeComboBox();

  QPushButton *okButton = new QPushButton("OK");
  QPushButton *cancelButton = new QPushButton("Cancel");

  QSpacerItem *spacerItem = new QSpacerItem(20, 20); // lo uso??
};

#endif // INSLAYOUT_H
