#ifndef CONTROLLER_H
#define CONTROLLER_H

#include <QMainWindow>
#include <QDesktopServices>

#include "store.h"
#include "elementsGUI/computerlistitem.h"
#include "elementsGUI/widgetcomputerlistitem.h"
#include "hierarchy/computer.h"
#include "hierarchy/desktop.h"
#include "hierarchy/laptop.h"
#include "hierarchy/tablet.h"

#include "myfiledialog.h"
#include "warningdialog.h"
#include <QUrl>
#include <QFileInfo>
#include <QDir>
#include <QDebug>

class BaseLayout;
class InsLayout;
class ToolDialog;
class SearchDialog;
class Controller: public QMainWindow
{
  Q_OBJECT
public:
  Controller(Store*);
  virtual ~Controller();

  Store *storePtr;                 // Puntatore a Store
  BaseLayout *baseLayoutPtr;       // Puntatore a BaseLayout
  InsLayout *insLayoutPtr;         // Puntatore a InsLayout
  ToolDialog *toolDialogPtr;       // Puntatore a ToolDialog
  WarningDialog *warningDialogPtr; // Puntatore a WarningDialog
  SearchDialog *searchDialogPtr;   // Puntatore a SearchDialog

public:
  int sortFlag = 0;
  bool flagCreated = true;      // flag usato per sapere se un Computer viene modificato o creato
  bool flagStart = true;        // flag usato per sapere se e' il primo avvio
  WidgetComputerListItem *widgetItemList = new WidgetComputerListItem();

public:
  void clearList();   // Cancella tutti gli elementi di QListWidget e cancella i contenuti di Qontainer
  void populateQListWidget(Qontainer<Computer*>&);  // Itera per il Qontainer, crea un ComputerListItem e chiama setupComputerListItem
  void setupComputerListItem(ComputerListItem*);    // Chiama ComputerListItem::setInfo(), setUpIcons() e BaseLayout::addItemQListWidget
  void setUpIcons(ComputerListItem*);               // Inserisce l'icona corretta rispetto al tipo di Computer


  void createConnectsBaseLayout();    // Crea le connessioni SIGNAL -> SLOT per BaseLayout
  void createConnectsInsLayout();     // Crea le connessioni SIGNAL -> SLOT per InsLayout
  void createConnectsSearchDialog();  // Crea le connessioni SIGNAL -> SLOT per SearchDialog
  void createConnectsToolDialog();    // Crea le connessioni SIGNAL -> SLOT per ToolDialog
  void createConnectsWarningDialog(); // Crea le connessioni SIGNAL -> SLOT per WarningDialog

public slots:
  // BaseLayout
  void showObjectInfoSlot(QListWidgetItem*) const; // Slot che cambia il contenuto di infoLabel e imgLabel di BaseLayout
  void removeSelectedSlot();                       // Slot che rimuove da QListWidget e Qontainer l'oggetto selezionato
  void removeAllItemsSlot();                       // Slot che rimuove da QListWidget e Qontainer tutti gli oggetti
  void orderPriceSlot();                           // Slot che ordina i computer della QListWidget dal prezzo massimo al prezzo minimo
  void closeBaseLayout();                          // Slot che chiude classe parent: Controller (Chiudendo tutti gli oggetti children)

  // MyFileDialog
  void openFileSlot();   // MyFileDialog: apertura file Json
  void saveFileSlot();   // MyFileDialog: salvataggio file Json

  // InsLayout
  void openInsertLayoutSlot();  // Slot che apre il dialog InsertLayout
  void openModifyLayoutSlot();  // Slot che apre il dialog InsertLayout dopo aver cambiato il flag: flagCreate
  void createObjectSlot();      // Slot che crea l'oggetto computer dopo aver scelto i valori in InsertLayout
  void rejectInsLayout() const; // Slot che chiude il dialog InsertLayout
  void modifyObjectSlot();      // Slot che modifica l'oggetto computer dopo aver scelto i valori in InsertLayout


  // SearchDialog
  void openSearchSlot();         // Slot che apre il dialog SearchDialog
  void filterBySlot();           // Slot che filtra gli oggetti correnti della lista // Devo prima cancellare resContainer e Container in Store
  void resetSearchSlot();        // Slot che resetta la ricerca
  void rejectSearchSlot() const; // Slot che chiude il dialog SearchDialog

  // ToolDialog
  void openToolDialogSlot();     // Slot che apre il dialog ToolDialog (prezzo totale ordinazione corrente)
  void rejectToolDialog() const; // Slot che chiude il dialog ToolDialog

  // WarningDialog
  void acceptWarningDialog();       // Slot che accetta il WarningDialog e quindi procede con l'operazione iniziata
  void rejectWarningDialog() const; // Slot che rifiuta il WarningDialog e quindi annulla l'operazione iniziata
};

#endif // CONTROLLER_H
