#ifndef TOOLDIALOG_H
#define TOOLDIALOG_H

#include <QDialog>
#include <QLabel>
#include <QVBoxLayout>
#include <QPushButton>

#include "controller.h"
#include "elementsGUI/stylegui.h"

class ToolDialog: public QDialog
{
  Q_OBJECT
public:
  ToolDialog(Controller*controller=nullptr);
  Controller *controllerPtr;

public:
  void createLayout();
  void restyleWidgets();

public:
  QVBoxLayout *vbox = new QVBoxLayout();
  QHBoxLayout *hbox = new QHBoxLayout();
  QLabel *priceLabel = new QLabel();
  QLabel *x = new QLabel("Prezzo totale ordinazione:");
  QPushButton *okButton = new QPushButton("OK");
};

#endif // TOOLDIALOG_H
