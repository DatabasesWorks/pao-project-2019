#ifndef WARNINGDIALOG_H
#define WARNINGDIALOG_H

#include <QDialog>
#include <QPushButton>
#include <QLabel>
#include <QFont>
#include <QVBoxLayout>

#include "elementsGUI/stylegui.h"

class WarningDialog : public QDialog
{
public:
  WarningDialog();

public:
  QVBoxLayout *verticalLayout = new QVBoxLayout();
  QHBoxLayout *horizontalLayout = new QHBoxLayout();
  QPushButton *okButton = new QPushButton("Ok");
  QPushButton *yesButton = new QPushButton("Si");
  QPushButton *noButton = new QPushButton("No");
  QLabel *modifyWarning = new QLabel();
};

#endif // WARNINGDIALOG_H
